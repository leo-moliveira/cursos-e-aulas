package com.lmo.fadergsn2;

public class Config {
    /*
    Password length rule
    Must be more then 6 for firebase
     */
    public static final int PASSWORD_LENGTH = 6;
}
